import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import CarCategories from "../components/CarCategories";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <CarCategories />
    </div>
  );
};

export default Index;