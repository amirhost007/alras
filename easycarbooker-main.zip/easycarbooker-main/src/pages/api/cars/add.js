import { query } from '../../../lib/db';

export default async (req, res) => {
  const { name, image_url, category_id, seating_capacity, fuel_type, airbags, transmission } = req.body;

  if (!name || !category_id || !seating_capacity || !fuel_type || airbags === undefined || !transmission) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const result = await query(
      `INSERT INTO cars (name, image_url, category_id, seating_capacity, fuel_type, airbags, transmission) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, image_url, category_id, seating_capacity, fuel_type, airbags, transmission]
    );
    res.status(201).json({ message: 'Car added successfully!' });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
};
