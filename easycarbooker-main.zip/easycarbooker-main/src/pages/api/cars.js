// pages/api/cars.js
import { query } from '../../lib/db';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      // Get all cars from the database
      const cars = await query('SELECT * FROM cars');
      res.status(200).json(cars);
    } catch (err) {
      console.error('Error fetching cars:', err);
      res.status(500).json({ error: 'Database error' });
    }
  } else if (req.method === 'POST') {
    const { name, model, category_id } = req.body;

    if (!name || !model || !category_id) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    try {
      // Insert car into the database
      await query(
        `INSERT INTO cars (name, model, category_id) VALUES (?, ?, ?)`,
        [name, model, category_id]
      );

      res.status(201).json({ message: 'Car added successfully!' });
    } catch (err) {
      console.error('Error adding car:', err);
      res.status(500).json({ error: 'Database error' });
    }
  } else {
    res.status(405).json({ error: 'Method Not Allowed' });
  }
}
