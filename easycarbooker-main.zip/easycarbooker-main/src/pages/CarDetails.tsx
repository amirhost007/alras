import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import BookingForm from "@/components/BookingForm";
import { cars } from "@/components/CarCategories";
import {
  ChevronDown,
  ChevronUp,
  Car,
  Star,
  DoorOpen,
  Settings,
  ShieldCheck,
  Briefcase,
  Thermometer,
  Music,
  Fuel,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CarDetails = () => {
  const { id } = useParams();
  const [mainImage, setMainImage] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showAttributes, setShowAttributes] = useState(false);

  const car = cars.find((c) => c.id === Number(id));

  if (!car) {
    return <div>Car not found</div>;
  }

  const carImages = [
    car.image,
    "https://images.unsplash.com/photo-1485291571150-772bcfc10da5?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMainImage((prev) => (prev + 1) % carImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [carImages.length]);

  const features = [
    { icon: <Thermometer className="h-5 w-5 text-primary" />, name: "AC", value: "Yes" },
    { icon: <Music className="h-5 w-5 text-primary" />, name: "Audio Input", value: "Bluetooth/AUX" },
    { icon: <Fuel className="h-5 w-5 text-primary" />, name: "Fuel Type", value: "Petrol" },
    { icon: <Users className="h-5 w-5 text-primary" />, name: "Seating Capacity", value: "5 People" },
  ];

  const attributes = [
    { icon: <DoorOpen className="h-5 w-5 text-primary" />, name: "Number of Doors", value: "4" },
    { icon: <Briefcase className="h-5 w-5 text-primary" />, name: "Luggage Capacity", value: "3 Large Bags" },
    { icon: <Settings className="h-5 w-5 text-primary" />, name: "Transmission", value: "Automatic" },
    { icon: <ShieldCheck className="h-5 w-5 text-primary" />, name: "Air Bags", value: "Yes" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-24 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-[16/9] overflow-hidden rounded-lg">
              <img src={carImages[mainImage]} alt={car.name} className="h-full w-full object-cover" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {carImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setMainImage(index)}
                  className={cn(
                    "aspect-[16/9] overflow-hidden rounded-lg border-2 transition-all duration-200",
                    mainImage === index
                      ? "border-primary ring-2 ring-primary ring-offset-2"
                      : "border-transparent hover:border-primary/50"
                  )}
                >
                  <img src={image} alt={`${car.name} view ${index + 1}`} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Car Details */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl font-bold">{car.name}</h1>
              <p className="mt-2 text-lg text-muted-foreground">{car.category}</p>
            </div>

            {/* Pricing Section */}
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg bg-neutral-50 p-4 text-center shadow-sm">
                <p className="text-sm text-neutral-600">Daily Rate</p>
                <p className="mt-1 text-2xl font-bold text-primary">${car.dailyPrice}</p>
              </div>
              <div className="rounded-lg bg-neutral-50 p-4 text-center shadow-sm">
                <p className="text-sm text-neutral-600">Weekly Rate</p>
                <p className="mt-1 text-2xl font-bold text-primary">${car.weeklyPrice}</p>
              </div>
              <div className="rounded-lg bg-neutral-50 p-4 text-center shadow-sm">
                <p className="text-sm text-neutral-600">Monthly Rate</p>
                <p className="mt-1 text-2xl font-bold text-primary">${car.monthlyPrice}</p>
              </div>
            </div>

            {/* Features Section */}
            <div className="border rounded-lg">
              <button
                onClick={() => setShowFeatures(!showFeatures)}
                className="flex items-center justify-between w-full p-3 bg-primary-light text-white rounded-t-lg"
              >
                <div className="flex items-center gap-3">
                  <span className="rounded-full bg-white p-2">
                    <Car className="h-5 w-5 text-primary" />
                  </span>
                  <span className="text-lg font-semibold">Features</span>
                </div>
                <span className="rounded-full bg-white p-2">
                  {showFeatures ? <ChevronUp className="h-5 w-5 text-primary" /> : <ChevronDown className="h-5 w-5 text-primary" />}
                </span>
              </button>
              {showFeatures && (
                <div className="p-4 grid grid-cols-2 gap-4 bg-white rounded-b-lg">
                  {features.map((feature) => (
                    <div key={feature.name} className="flex items-center gap-2">
                      <span className="rounded-full bg-primary/10 p-2">{feature.icon}</span>
                      <div>
                        <p className="text-sm font-medium">{feature.name}</p>
                        <p className="text-sm text-gray-600">{feature.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
           {/* Attributes Section */}
<div className="border rounded-lg">
  <button
    onClick={() => setShowAttributes(!showAttributes)}
    className="flex items-center justify-between w-full p-3 bg-primary-light text-white rounded-t-lg"
  >
    <div className="flex items-center gap-3">
      <span className="rounded-full bg-white p-2">
        <Star className="h-5 w-5 text-primary" /> {/* Changed icon from Info to Star */}
      </span>
      <span className="text-lg font-semibold">Attributes</span>
    </div>
    <span className="rounded-full bg-white p-2">
      {showAttributes ? <ChevronUp className="h-5 w-5 text-primary" /> : <ChevronDown className="h-5 w-5 text-primary" />}
    </span>
  </button>
  {showAttributes && (
    <div className="p-4 grid grid-cols-2 gap-4 bg-white rounded-b-lg">
      {attributes.map((attribute) => (
        <div key={attribute.name} className="flex items-center gap-2">
          <span className="rounded-full bg-primary/10 p-2">{attribute.icon}</span>
          <div>
            <p className="text-sm font-medium">{attribute.name}</p>
            <p className="text-sm text-gray-600">{attribute.value}</p>
          </div>
        </div>
      ))}
    </div>
  )}
</div>

            {/* Booking Form */}
            <BookingForm carId={car.id} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default CarDetails;
