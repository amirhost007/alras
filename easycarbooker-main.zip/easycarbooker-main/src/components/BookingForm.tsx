import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Clock, Car, ChevronDown, ChevronUp, Key, Star } from "lucide-react";

interface BookingFormProps {
  carId: number;
}

const locations = [
  "New York City",
  "Los Angeles",
  "Chicago",
  "Houston",
  "Phoenix",
  "Philadelphia",
];

const BookingForm = ({ carId }: BookingFormProps) => {
  const { toast } = useToast();
  const [additionalDriver, setAdditionalDriver] = useState<boolean>(false);
  const [insurance, setInsurance] = useState<boolean>(false);
  const [showForm, setShowForm] = useState<boolean>(true);
  const [pickupDate, setPickupDate] = useState<string>("");
  const [returnDate, setReturnDate] = useState<string>("");
  const [pickupTime, setPickupTime] = useState<string>("");
  const [returnTime, setReturnTime] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Booking Submitted",
      description: "Your booking request has been received. Redirecting to checkout...",
    });
  };

  // Disable past dates and ensure return date is not before pickup date
  const minDate = new Date().toISOString().split("T")[0];
  const minReturnDate = pickupDate ? pickupDate : minDate;

  // Ensure only future times can be selected based on the current time
  const getMinTime = () => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    return `${currentHour + (currentMinute > 30 ? 1 : 0)}:00`;
  };

  const minPickupTime = getMinTime();

  // Calculate minimum return time based on pickup time and return date
  const getMinReturnTime = () => {
    if (pickupDate === returnDate) {
      return pickupTime; // Return time must be after pickup time on the same day
    }
    return "00:00"; // Default minimum time for different days
  };

  const minReturnTime = getMinReturnTime();

  return (
    <div className="border rounded-lg">
      <button
        onClick={() => setShowForm(!showForm)}
        className="flex items-center justify-between w-full p-3 bg-primary-light text-white rounded-t-lg"
      >
        <div className="flex items-center gap-3">
          <span className="rounded-full bg-white p-2">
            <Car className="h-5 w-5 text-primary" />
          </span>
          <span className="text-lg font-semibold">Book Your Car</span>
        </div>
        <span className="rounded-full bg-white p-2">
          {showForm ? <ChevronUp className="h-5 w-5 text-primary" /> : <ChevronDown className="h-5 w-5 text-primary" />}
        </span>
      </button>
      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-8 rounded-b-lg bg-white p-6">
          <h2 className="text-2xl font-semibold">Book Your Car</h2>
          
          <div className="grid gap-6 md:grid-cols-2">
            {/* Pickup Location */}
            <div className="space-y-2">
              <Label htmlFor="pickupLocation">Pickup Location</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select pickup location" />
                </SelectTrigger>
                <SelectContent className="bg-primary text-white">
                  {locations.map((location) => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Return Location */}
            <div className="space-y-2">
              <Label htmlFor="returnLocation">Return Location</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select return location" />
                </SelectTrigger>
                <SelectContent className="bg-primary text-white">
                  {locations.map((location) => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Pickup Date */}
            <div className="space-y-2">
              <Label htmlFor="pickupDate">Pickup Date</Label>
              <div className="relative">
                <Input
                  id="pickupDate"
                  type="date"
                  required
                  min={minDate}
                  value={pickupDate}
                  onChange={(e) => setPickupDate(e.target.value)}
                  className="pr-10"
                  onFocus={(e) => e.target.showPicker()} // Open calendar on input focus
                />
                <Calendar
                  className="absolute right-3 top-2.5 h-5 w-5 text-primary cursor-pointer"
                  onClick={() => (document.getElementById('pickupDate') as HTMLInputElement)?.showPicker()} // Cast to HTMLInputElement
                />
              </div>
            </div>

            {/* Return Date */}
            <div className="space-y-2">
              <Label htmlFor="returnDate">Return Date</Label>
              <div className="relative">
                <Input
                  id="returnDate"
                  type="date"
                  required
                  min={minReturnDate}
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="pr-10"
                  onFocus={(e) => e.target.showPicker()} // Open calendar on input focus
                />
                <Calendar
                  className="absolute right-3 top-2.5 h-5 w-5 text-primary cursor-pointer"
                  onClick={() => (document.getElementById('returnDate') as HTMLInputElement)?.showPicker()} // Cast to HTMLInputElement
                />
              </div>
            </div>

            {/* Pickup Time */}
            <div className="space-y-2">
              <Label htmlFor="pickupTime">Pickup Time</Label>
              <div className="relative">
                <Input
                  id="pickupTime"
                  type="time"
                  required
                  min={minPickupTime}
                  value={pickupTime}
                  onChange={(e) => setPickupTime(e.target.value)}
                  className="pr-10"
                  onFocus={(e) => e.target.showPicker()} // Open time picker on input focus
                />
                <Clock
                  className="absolute right-3 top-2.5 h-5 w-5 text-primary cursor-pointer"
                  onClick={() => (document.getElementById('pickupTime') as HTMLInputElement)?.showPicker()} // Cast to HTMLInputElement
                />
              </div>
            </div>

            {/* Return Time */}
            <div className="space-y-2">
              <Label htmlFor="returnTime">Return Time</Label>
              <div className="relative">
                <Input
                  id="returnTime"
                  type="time"
                  required
                  min={minReturnTime}
                  value={returnTime}
                  onChange={(e) => setReturnTime(e.target.value)}
                  className="pr-10"
                  onFocus={(e) => e.target.showPicker()} // Open time picker on input focus
                />
                <Clock
                  className="absolute right-3 top-2.5 h-5 w-5 text-primary cursor-pointer"
                  onClick={() => (document.getElementById('returnTime') as HTMLInputElement)?.showPicker()} // Cast to HTMLInputElement
                />
              </div>
            </div>
          </div>

          {/* Additional Options */}
          <div className="space-y-4">
            <div className="flex items-center justify-between space-x-4">
              <div>
                <Label>Additional Driver</Label>
                <p className="text-sm text-muted-foreground">
                  Add another person to drive the vehicle
                </p>
              </div>
              <Switch
                checked={additionalDriver}
                onCheckedChange={setAdditionalDriver}
              />
            </div>

            <div className="flex items-center justify-between space-x-4">
              <div>
                <Label>Personal Accident Insurance</Label>
                <p className="text-sm text-muted-foreground">
                  Add insurance coverage for your rental period
                </p>
              </div>
              <Switch
                checked={insurance}
                onCheckedChange={setInsurance}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" className="w-auto">
              Proceed to Rent
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default BookingForm;