import { useState } from "react";
import { Button } from "@/components/ui/button";
import CarCard from "./CarCard";

const categories = [
  "All",
  "Economic Sedan",
  "Sedan",
  "SUV",
  "Compact SUV",
  "4x4 SUV",
];

export const cars = [
  {
    id: 1,
    name: "Toyota Corolla",
    category: "Economic Sedan",
    image: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80",
    dailyPrice: 50,
    weeklyPrice: 300,
    monthlyPrice: 1000,
  },
  {
    id: 2,
    name: "Honda Accord",
    category: "Sedan",
    image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?auto=format&fit=crop&w=800&q=80",
    dailyPrice: 65,
    weeklyPrice: 400,
    monthlyPrice: 1300,
  },
  {
    id: 3,
    name: "Toyota RAV4",
    category: "Compact SUV",
    image: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=800&q=80",
    dailyPrice: 75,
    weeklyPrice: 450,
    monthlyPrice: 1500,
  },
];

const CarCategories = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredCars = cars.filter(
    (car) => selectedCategory === "All" || car.category === selectedCategory
  );

  return (
    <section className="py-16">
      <div className="container">
        <h2 className="mb-8 text-center text-3xl font-bold md:text-4xl">
          Our Fleet
        </h2>
        <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="rounded-full"
            >
              {category}
            </Button>
          ))}
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCars.length > 0 ? (
            filteredCars.map((car) => (
              <CarCard
                key={car.id}
                id={car.id}
                name={car.name}
                image={car.image}
                category={car.category}
                dailyPrice={car.dailyPrice}
                weeklyPrice={car.weeklyPrice}
                monthlyPrice={car.monthlyPrice}
              />
            ))
          ) : (
            <div className="col-span-full rounded-lg bg-neutral-50 p-8 text-center">
              <p className="text-lg text-neutral-600">
                No cars available in this category at the moment.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default CarCategories;