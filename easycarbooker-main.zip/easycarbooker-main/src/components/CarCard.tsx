import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface CarCardProps {
  id: number;
  name: string;
  image: string;
  dailyPrice: number;
  weeklyPrice: number;
  monthlyPrice: number;
  category: string;
}

const CarCard = ({
  id,
  name,
  image,
  dailyPrice,
  weeklyPrice,
  monthlyPrice,
  category,
}: CarCardProps) => {
  const navigate = useNavigate();

  return (
    <Card className="car-card overflow-hidden">
      <div className="relative aspect-[16/9] overflow-hidden">
        <img
          src={image}
          alt={name}
          className="car-image absolute inset-0 h-full w-full object-cover"
        />
      </div>
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-xl font-semibold">{name}</h3>
          <span className="rounded-full bg-primary/10 px-3 py-1 text-sm text-primary">
            {category}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="rounded-lg bg-neutral-50 p-3 text-center">
            <p className="text-sm text-neutral-600">Daily Rate</p>
            <p className="mt-1 font-semibold text-primary">
              ${dailyPrice}
            </p>
          </div>
          <div className="rounded-lg bg-neutral-50 p-3 text-center">
            <p className="text-sm text-neutral-600">Weekly Rate</p>
            <p className="mt-1 font-semibold text-primary">
              ${weeklyPrice}
            </p>
          </div>
          <div className="rounded-lg bg-neutral-50 p-3 text-center">
            <p className="text-sm text-neutral-600">Monthly Rate</p>
            <p className="mt-1 font-semibold text-primary">
              ${monthlyPrice}
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button 
          onClick={() => navigate(`/car/${id}`)} 
          className="w-full"
        >
          Book Now
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CarCard;