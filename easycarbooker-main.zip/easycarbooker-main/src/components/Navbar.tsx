import { useState } from "react";
import { Menu, X, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 z-50 w-full bg-white/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-primary">LuxCars</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <NavigationMenu>
              <NavigationMenuList className="flex items-center space-x-8">
                <NavigationMenuItem>
                  <Link to="/" className="nav-link">
                    Home
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/about" className="nav-link">
                    About Us
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger className="nav-link">
                    Leasing
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="min-w-[200px] bg-white p-2">
                      <Link
                        to="/corporate-leasing"
                        className="block rounded-md px-3 py-2 text-sm text-neutral-900 hover:bg-neutral-100"
                      >
                        Corporate Leasing
                      </Link>
                      <Link
                        to="/personal-leasing"
                        className="block rounded-md px-3 py-2 text-sm text-neutral-900 hover:bg-neutral-100"
                      >
                        Personal Leasing
                      </Link>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/faqs" className="nav-link">
                    FAQs
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/contact" className="nav-link">
                    Contact Us
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link
                    to="/login"
                    className="button-primary flex items-center space-x-2"
                  >
                    <span>Login</span>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Mobile Navigation Button */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center rounded-md p-2 text-neutral-600 hover:text-neutral-900 focus:outline-none"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isOpen && (
          <div className="md:hidden">
            <div className="space-y-4 px-2 pb-3 pt-2">
              <Link
                to="/"
                className="block rounded-md px-3 py-2 text-base font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
              >
                Home
              </Link>
              <Link
                to="/about"
                className="block rounded-md px-3 py-2 text-base font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
              >
                About Us
              </Link>
              <div className="relative">
                <button
                  className="flex w-full items-center justify-between rounded-md px-3 py-2 text-base font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                  onClick={(e) => e.preventDefault()}
                >
                  <span>Leasing</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
                <div className="ml-4 space-y-2">
                  <Link
                    to="/corporate-leasing"
                    className="block rounded-md px-3 py-2 text-sm text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                  >
                    Corporate Leasing
                  </Link>
                  <Link
                    to="/personal-leasing"
                    className="block rounded-md px-3 py-2 text-sm text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                  >
                    Personal Leasing
                  </Link>
                </div>
              </div>
              <Link
                to="/faqs"
                className="block rounded-md px-3 py-2 text-base font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
              >
                FAQs
              </Link>
              <Link
                to="/contact"
                className="block rounded-md px-3 py-2 text-base font-medium text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
              >
                Contact Us
              </Link>
              <Link to="/login" className="button-primary w-full">
                Login
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
